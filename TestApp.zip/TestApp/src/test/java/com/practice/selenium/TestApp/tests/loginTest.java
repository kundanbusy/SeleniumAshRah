package com.practice.selenium.TestApp.tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.practice.selenium.TestApp.pageObjects.loginPageObject;

public class loginTest extends baseTest{
	
	
	
	
	@Test
	public void test001() throws InterruptedException,AssertionError, IOException
	{
		
		//System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		
		loginPageObject lp=new loginPageObject(driver);
		
		driver.get(url);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		lp.setUsername(uname);
		lp.setPassword(pass);
		lp.clickButton();
		//Thread.sleep(7000);
		//driver.switchTo().alert().accept();
		Thread.sleep(3000);
		
		Assert.assertEquals(lp.getLogout().getText(), "Log out");

		if(lp.getLogout().getText().equals("Lo out"))
			Assert.assertTrue(true);
		else
		{
			captureScrShot(driver, "loginTest");
			Assert.assertTrue(false);
		}
		
		driver.quit();
	}
	

}
