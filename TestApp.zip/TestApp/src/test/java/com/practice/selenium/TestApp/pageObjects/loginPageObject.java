package com.practice.selenium.TestApp.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginPageObject {
	
	WebDriver ldriver;
	
	public loginPageObject(WebDriver driver) {
		ldriver = driver;
		PageFactory.initElements(driver, this);
		
	}

	//private WebDriver ldriver;
	
	@FindBy(name = "uid")
	private WebElement uname;
	
	@FindBy(name = "password")
	private WebElement pass;
	
	@FindBy(name = "btnLogin")
	private WebElement submit;
	
	
	private WebElement logout;
	
	//actions
	
	public void setUsername(String username)
	{
		uname.sendKeys(username);
	}

	public void setPassword(String password)
	{
		pass.sendKeys(password);
	}
	
	public void clickButton()
	{
		submit.click();
	}
	
	public void logout()
	{
		logout.click();
	}
	
	public WebElement getLogout()
	{
		logout=ldriver.findElement(By.linkText("Log out"));
		return logout;
	}
	
	
}
