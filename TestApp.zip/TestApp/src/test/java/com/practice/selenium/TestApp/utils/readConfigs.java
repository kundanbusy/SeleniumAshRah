package com.practice.selenium.TestApp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class readConfigs {

	Properties pro;
	
	public readConfigs() {
		
		File src = new File("./configs/app.properties");
		
		pro = new Properties();
		try {
		FileInputStream fin= new FileInputStream(src);
		pro.load(fin);}
		catch(IOException ex)
		{
			System.out.println("Config File Not Found !!!");
		}
		
	}
	
	public String getUrl()
	{
		return pro.getProperty("url");
	}
	
	public String getUname()
	{
		return pro.getProperty("uname");
	}
	
	public String getPass()
	{
		return pro.getProperty("pass");
	}
	
	

}
