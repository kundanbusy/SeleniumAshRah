package com.practice.selenium.TestApp.tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import com.practice.selenium.TestApp.utils.readConfigs;

public class baseTest {
	
	
	readConfigs configs= new readConfigs();
	WebDriver driver;
	
	public String url=configs.getUrl();
	public String uname =configs.getUname();
	public String pass =configs.getPass();
	
	@Parameters("browser")
	@BeforeClass
	public void setup(String br)
	{

		
		switch (br) {
		
		case "IntExp":		driver=new InternetExplorerDriver();
		System.setProperty("webdriver.ie.driver","./Driver/IEDriverServer.exe");
			break;
		case "chrome":		driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			break;
			

		}
	}
	
	@AfterClass
	public void end()
	{
		driver.quit();
	}
	
	public void captureScrShot(WebDriver dr,String fileName) throws IOException
	{
		TakesScreenshot scr=(TakesScreenshot)dr;
		
		File src=scr.getScreenshotAs(OutputType.FILE);
		File dest= new File("./Screenshots/"+fileName+".png");
		
		FileUtils.copyFile(src, dest);
		
	}

	//baseTest ref = new baseTest();
}
